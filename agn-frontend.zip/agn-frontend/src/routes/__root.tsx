import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AccountSession } from "@/components/account-session";
import { ShopCartSync } from "@/components/shop-cart";
import { supabase } from "@/integrations/supabase/client";
import { AgnNavigation } from "@/components/agn-brand";
import { applyTheme, isThemeKey, readStoredTheme } from "@/lib/theme";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#00E5FF" },
      { name: "apple-mobile-web-app-title", content: "AGN" },
      { title: "AGN — Aether Gaming Networks | EWL Groups Inc." },
      { name: "description", content: "AGN (Aether Gaming Networks) competitive arena and Wagerer Vault, an EWL Groups Inc. property." },
      { name: "author", content: "EWL Groups Inc." },
      { property: "og:title", content: "AGN — Aether Gaming Networks | EWL Groups Inc." },
      { property: "og:description", content: "AGN (Aether Gaming Networks) competitive arena and Wagerer Vault, an EWL Groups Inc. property." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700&family=Rajdhani:wght@500;600;700&family=JetBrains+Mono:wght@400;600&family=Cinzel:wght@600;700;800&family=Space+Grotesk:wght@400;500;600&display=swap",
      },
      { rel: "icon", href: "/favicon.png", type: "image/png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/assets/icons/agn-launcher-192.png" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <AccountSession>
      <ShopCartSync />
      <AuthReturn />
      <ThemeSync />
      <AgnNavigation />
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
      </AccountSession>
    </QueryClientProvider>
  );
}

// Applies the remembered appearance theme after hydration. Runs once on
// mount and never reloads the page, so routes, sessions, form input and
// playing media are untouched when the theme changes.
function ThemeSync() {
  useEffect(() => {
    applyTheme(readStoredTheme());
    // Signed-in members get their saved theme (Simple Gold for new sign-ups).
    const load = () => supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: row } = await supabase.from("profiles").select("theme_key").eq("id", data.user.id).maybeSingle();
      if (row && isThemeKey(row.theme_key)) applyTheme(row.theme_key);
    });
    void load();
    const { data: sub } = supabase.auth.onAuthStateChange((event) => { if (event === "SIGNED_IN") void load(); });
    return () => sub.subscription.unsubscribe();
  }, []);
  return null;
}

function AuthReturn() {
  const router = useRouter();
  useEffect(() => {
    if (window.sessionStorage.getItem("agn-auth-return") !== "/account") return;
    void supabase.auth.getUser().then(({ data }) => {
      if (!data.user) return;
      window.sessionStorage.removeItem("agn-auth-return");
      void router.navigate({ to: "/account", replace: true });
    });
  }, [router]);
  return null;
}
